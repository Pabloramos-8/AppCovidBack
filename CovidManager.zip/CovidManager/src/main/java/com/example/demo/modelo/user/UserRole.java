package com.example.demo.modelo.user;

public enum UserRole {
	USER,ADMIN;

}
